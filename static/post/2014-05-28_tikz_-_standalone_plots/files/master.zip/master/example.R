# load data

## @knitr load_data
my_data <- read.delim("my_data.txt")
summary(my_data)

library(ggplot2)